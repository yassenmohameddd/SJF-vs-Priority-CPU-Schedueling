package gui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import model.Process;
import scheduler.*;
import metrics.MetricsCalculator;

public class MainGUI extends JFrame {

    // ── Input fields ──────────────────────────────────────────────
    private JTextField fId, fAt, fBt, fPri;
    private JRadioButton rbSJF, rbPriority;
    private ButtonGroup algoGroup;

    // ── Tables ────────────────────────────────────────────────────
    private JTable sjfTable, prioTable, compareTable;
    private DefaultTableModel sjfModel, prioModel, compareModel;

    // ── Gantt charts ──────────────────────────────────────────────
    private GanttChartPanel sjfChart, prioChart;

    // ── Conclusion text area ──────────────────────────────────────
    private JTextArea conclusionArea;

    // ── Process input storage (ID, AT, BT, Pri) ──────────────────
    private DefaultTableModel inputModel;
    private JTable inputTable;

    public MainGUI() {
        setTitle("OS Scheduling Simulator - SJF vs Priority");
        setSize(1400, 900);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(5, 5));


        JPanel topPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 8));
        topPanel.setBorder(new EmptyBorder(4, 6, 4, 6));

        topPanel.add(new JLabel("ID:"));
        fId = new JTextField(4); topPanel.add(fId);

        topPanel.add(new JLabel("Arrival (AT):"));
        fAt = new JTextField(4); topPanel.add(fAt);

        topPanel.add(new JLabel("Burst (BT):"));
        fBt = new JTextField(4); topPanel.add(fBt);

        topPanel.add(new JLabel("Priority (Pri):"));
        fPri = new JTextField(4); topPanel.add(fPri);

        JButton btnAdd = new JButton("Add Process");
        topPanel.add(btnAdd);

    
        rbSJF      = new JRadioButton("SJF");
        rbPriority = new JRadioButton("Priority", true);
        algoGroup  = new ButtonGroup();
        algoGroup.add(rbSJF);
        algoGroup.add(rbPriority);
        topPanel.add(rbSJF);
        topPanel.add(rbPriority);

        JButton btnRunSingle  = new JButton("Run Single");
        JButton btnCompareBoth = new JButton("Compare Both");
        JButton btnClear      = new JButton("Clear All");
        topPanel.add(btnRunSingle);
        topPanel.add(btnCompareBoth);
        topPanel.add(btnClear);

        add(topPanel, BorderLayout.NORTH);


        JPanel mainContent = new JPanel();
        mainContent.setLayout(new BoxLayout(mainContent, BoxLayout.Y_AXIS));
        mainContent.setBorder(new EmptyBorder(6, 8, 8, 8));

        
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.setBorder(BorderFactory.createTitledBorder("Process Input List"));
        String[] inputCols = {"ID", "AT", "BT", "Pri"};
        inputModel = new DefaultTableModel(inputCols, 0);
        inputTable = new JTable(inputModel);
        inputTable.setRowHeight(22);
        JScrollPane inputScroll = new JScrollPane(inputTable);
        inputScroll.setPreferredSize(new Dimension(1300, 110));
        inputScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 110));
        inputPanel.add(inputScroll);
        mainContent.add(inputPanel);
        mainContent.add(Box.createVerticalStrut(8));

        
        JPanel compPanel = new JPanel(new BorderLayout());
        compPanel.setBorder(BorderFactory.createTitledBorder("Algorithms Comparison Analysis"));
        String[] compCols = {"Metric", "SJF", "Priority", "Winner"};
        compareModel = new DefaultTableModel(compCols, 0);
        compareTable = new JTable(compareModel);
        compareTable.setRowHeight(24);
        styleCompareTable();
        JScrollPane compScroll = new JScrollPane(compareTable);
        compScroll.setPreferredSize(new Dimension(1300, 110));
        compScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 110));
        compPanel.add(compScroll);
        mainContent.add(compPanel);
        mainContent.add(Box.createVerticalStrut(8));

        
        JPanel tablesRow = new JPanel(new GridLayout(1, 2, 10, 0));
        tablesRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 0));

        String[] resCols = {"ID", "AT", "BT", "Pri", "CT", "TAT", "WT", "RT"};

        sjfModel = new DefaultTableModel(resCols, 0);
        sjfTable = new JTable(sjfModel);
        sjfTable.setRowHeight(22);
        JScrollPane sjfScroll = new JScrollPane(sjfTable);
        JPanel sjfPanel = new JPanel(new BorderLayout());
        sjfPanel.setBorder(BorderFactory.createTitledBorder("SJF Full Results"));
        sjfPanel.add(sjfScroll);
        tablesRow.add(sjfPanel);

        prioModel = new DefaultTableModel(resCols, 0);
        prioTable = new JTable(prioModel);
        prioTable.setRowHeight(22);
        JScrollPane prioScroll = new JScrollPane(prioTable);
        JPanel prioPanel = new JPanel(new BorderLayout());
        prioPanel.setBorder(BorderFactory.createTitledBorder("Priority Full Results"));
        prioPanel.add(prioScroll);
        tablesRow.add(prioPanel);

        mainContent.add(tablesRow);
        mainContent.add(Box.createVerticalStrut(10));

        
        JPanel ganttRow = new JPanel(new GridLayout(1, 2, 10, 0));
        ganttRow.setMaximumSize(new Dimension(Integer.MAX_VALUE, 140));

        sjfChart = new GanttChartPanel();
        sjfChart.setPreferredSize(new Dimension(600, 120));
        JPanel sjfGanttPanel = new JPanel(new BorderLayout());
        sjfGanttPanel.setBorder(BorderFactory.createTitledBorder("SJF Gantt"));
        sjfGanttPanel.add(sjfChart);
        ganttRow.add(sjfGanttPanel);

        prioChart = new GanttChartPanel();
        prioChart.setPreferredSize(new Dimension(600, 120));
        JPanel prioGanttPanel = new JPanel(new BorderLayout());
        prioGanttPanel.setBorder(BorderFactory.createTitledBorder("Priority Gantt"));
        prioGanttPanel.add(prioChart);
        ganttRow.add(prioGanttPanel);

        mainContent.add(ganttRow);
        mainContent.add(Box.createVerticalStrut(12));

        
        JPanel conclusionPanel = new JPanel(new BorderLayout());
        conclusionPanel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(70, 130, 180), 2),
            "  Conclusion & Analysis Report  ",
            TitledBorder.LEFT, TitledBorder.TOP,
            new Font("Arial", Font.BOLD, 13), new Color(70, 130, 180)
        ));

        conclusionArea = new JTextArea(22, 80);
        conclusionArea.setEditable(false);
        conclusionArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        conclusionArea.setBackground(new Color(250, 252, 255));
        conclusionArea.setBorder(new EmptyBorder(8, 10, 8, 10));
        conclusionArea.setLineWrap(true);
        conclusionArea.setWrapStyleWord(true);
        conclusionArea.setText(getDefaultConclusionText());

        JScrollPane conclusionScroll = new JScrollPane(conclusionArea);
        conclusionScroll.setPreferredSize(new Dimension(800, 380));
        conclusionScroll.setMaximumSize(new Dimension(Integer.MAX_VALUE, 380));
        conclusionPanel.add(conclusionScroll);
        mainContent.add(conclusionPanel);

        
        JScrollPane outerScroll = new JScrollPane(mainContent);
        outerScroll.getVerticalScrollBar().setUnitIncrement(16);
        add(outerScroll, BorderLayout.CENTER);


        btnAdd.addActionListener(e -> addProcess());
        btnRunSingle.addActionListener(e -> runSingle());
        btnCompareBoth.addActionListener(e -> runCompareBoth());
        btnClear.addActionListener(e -> clearAll());
    }

    private void addProcess() {
        if (!validateInputs()) return;

        String idInput = fId.getText().trim();
        String formattedId = idInput.matches("\\d+") ? "P" + idInput : idInput;

        // Check duplicate ID
        for (int i = 0; i < inputModel.getRowCount(); i++) {
            if (inputModel.getValueAt(i, 0).toString().equalsIgnoreCase(formattedId)) {
                JOptionPane.showMessageDialog(this,
                    "Duplicate ID '" + formattedId + "'! Each process must have a unique ID.",
                    "Duplicate ID", JOptionPane.WARNING_MESSAGE);
                return;
            }
        }

        inputModel.addRow(new Object[]{
            formattedId, fAt.getText().trim(), fBt.getText().trim(), fPri.getText().trim()
        });
        clearInputFields();
    }


    private void runSingle() {
        if (inputModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Please add at least one process first.");
            return;
        }
        List<Process> list = collectProcesses();

        if (rbSJF.isSelected()) {
            List<Process> copy = deepCopy(list);
            var gantt = SJFScheduler.calculate(copy);
            fillResultTable(sjfModel, copy);
            sjfChart.setData(gantt);
      
            prioModel.setRowCount(0);
            prioChart.setData(null);
            compareModel.setRowCount(0);
            conclusionArea.setText(getDefaultConclusionText());
        } else {
            List<Process> copy = deepCopy(list);
            var gantt = PriorityScheduler.calculate(copy);
            fillResultTable(prioModel, copy);
            prioChart.setData(gantt);
            
            sjfModel.setRowCount(0);
            sjfChart.setData(null);
            compareModel.setRowCount(0);
            conclusionArea.setText(getDefaultConclusionText());
        }
    }


    private void runCompareBoth() {
        if (inputModel.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Please add at least one process first.");
            return;
        }
        List<Process> base = collectProcesses();

        List<Process> listSJF  = deepCopy(base);
        List<Process> listPrio = deepCopy(base);

        var sjfGantt  = SJFScheduler.calculate(listSJF);
        var prioGantt = PriorityScheduler.calculate(listPrio);

        fillResultTable(sjfModel,  listSJF);
        fillResultTable(prioModel, listPrio);

        sjfChart.setData(sjfGantt);
        prioChart.setData(prioGantt);

        
        compareModel.setRowCount(0);
        addComparisonRow("Avg Waiting Time (WT)",    MetricsCalculator.getAvgWT(listSJF),  MetricsCalculator.getAvgWT(listPrio));
        addComparisonRow("Avg Turnaround (TAT)",      MetricsCalculator.getAvgTAT(listSJF), MetricsCalculator.getAvgTAT(listPrio));
        addComparisonRow("Avg Response Time (RT)",    MetricsCalculator.getAvgRT(listSJF),  MetricsCalculator.getAvgRT(listPrio));

        
        conclusionArea.setText(buildConclusion(listSJF, listPrio));
        conclusionArea.setCaretPosition(0);
    }


    private List<Process> collectProcesses() {
        List<Process> list = new ArrayList<>();
        for (int i = 0; i < inputModel.getRowCount(); i++) {
            String id = inputModel.getValueAt(i, 0).toString();
            int at  = Integer.parseInt(inputModel.getValueAt(i, 1).toString());
            int bt  = Integer.parseInt(inputModel.getValueAt(i, 2).toString());
            int pri = Integer.parseInt(inputModel.getValueAt(i, 3).toString());
            list.add(new Process(id, at, bt, pri));
        }
        return list;
    }

    private List<Process> deepCopy(List<Process> src) {
        List<Process> copy = new ArrayList<>();
        for (Process p : src) copy.add(new Process(p.id, p.at, p.bt, p.pri));
        return copy;
    }

    private void fillResultTable(DefaultTableModel model, List<Process> list) {
        model.setRowCount(0);
        for (Process p : list) {
            model.addRow(new Object[]{p.id, p.at, p.bt, p.pri, p.ct, p.tat, p.wt, p.rt});
        }
    }

    private void addComparisonRow(String metric, double v1, double v2) {
        String winner = (v1 < v2) ? "SJF" : (v2 < v1 ? "Priority" : "Tie");
        compareModel.addRow(new Object[]{
            metric, String.format("%.2f", v1), String.format("%.2f", v2), winner
        });
    }

    private void styleCompareTable() {
        compareTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object val,
                    boolean sel, boolean foc, int row, int col) {
                Component c = super.getTableCellRendererComponent(t, val, sel, foc, row, col);
                if (col == 3 && val != null) {
                    String v = val.toString();
                    if (v.equals("SJF"))      c.setForeground(new Color(0, 120, 0));
                    else if (v.equals("Priority")) c.setForeground(new Color(180, 80, 0));
                    else                           c.setForeground(Color.BLUE);
                    ((JLabel) c).setFont(((JLabel) c).getFont().deriveFont(Font.BOLD));
                } else {
                    c.setForeground(Color.BLACK);
                }
                return c;
            }
        });
    }

    private boolean validateInputs() {
        String idTxt = fId.getText().trim();
        if (idTxt.isEmpty()) {
            JOptionPane.showMessageDialog(this, "ID cannot be empty!"); return false;
        }
        try {
            int at  = Integer.parseInt(fAt.getText().trim());
            int bt  = Integer.parseInt(fBt.getText().trim());
            int pri = Integer.parseInt(fPri.getText().trim());
            if (at < 0 || bt <= 0 || pri < 0) {
                JOptionPane.showMessageDialog(this,
                    "AT must be >= 0, BT must be > 0, Priority must be >= 0!");
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "AT, BT, and Pri must be numeric values!");
            return false;
        }
        return true;
    }

    private void clearInputFields() {
        fId.setText(""); fAt.setText(""); fBt.setText(""); fPri.setText("");
    }

    private void clearAll() {
        inputModel.setRowCount(0);
        sjfModel.setRowCount(0);
        prioModel.setRowCount(0);
        compareModel.setRowCount(0);
        sjfChart.setData(null);
        prioChart.setData(null);
        conclusionArea.setText(getDefaultConclusionText());
        clearInputFields();
    }


    private String buildConclusion(List<Process> sjfList, List<Process> prioList) {
        double avgWT_SJF  = MetricsCalculator.getAvgWT(sjfList);
        double avgTAT_SJF = MetricsCalculator.getAvgTAT(sjfList);
        double avgRT_SJF  = MetricsCalculator.getAvgRT(sjfList);
        double avgWT_P    = MetricsCalculator.getAvgWT(prioList);
        double avgTAT_P   = MetricsCalculator.getAvgTAT(prioList);
        double avgRT_P    = MetricsCalculator.getAvgRT(prioList);

        StringBuilder sb = new StringBuilder();

        
        sb.append("══════════════════════════════════════════════════════════════════════\n");
        sb.append("  1. ALGORITHM DESCRIPTIONS & SELECTION BASIS\n");
        sb.append("══════════════════════════════════════════════════════════════════════\n\n");

        sb.append("► SJF (Shortest Job First) :\n");
        sb.append("  • Selects the process with the SHORTEST Burst Time from the\n");
        sb.append("    Ready Queue at each scheduling decision point.\n");
        sb.append("  • Once a process starts executing, it runs to COMPLETION .\n");
        sb.append("  • Tie-breaking: if two processes have equal BT, the one that arrived\n");
        sb.append("    first (lower AT) is selected.\n");
        sb.append("  • Goal: minimize average Waiting Time across all processes.\n\n");

        sb.append("► Priority Scheduling :\n");
        sb.append("  • Selects the process with the HIGHEST PRIORITY (lowest priority number)\n");
        sb.append("    from the Ready Queue at each scheduling decision point.\n");
        sb.append("  • Once a process starts executing, it runs to COMPLETION .\n");
        sb.append("  • Tie-breaking: equal priority → lower AT wins; equal AT → lower BT wins.\n");
        sb.append("  • Goal: ensure urgent/critical processes execute before less urgent ones.\n\n");

        
        sb.append("► Starvation Analysis:\n");
        
        List<String> sjfStarved = new ArrayList<>();
        for (Process p : sjfList) {
            if (p.wt > 3 * p.bt) sjfStarved.add(p.id + " (WT=" + p.wt + ")");
        }
        if (sjfStarved.isEmpty()) {
            sb.append("  SJF:      No starvation detected in this workload.\n");
        } else {
            sb.append("  SJF:      ⚠ Possible starvation — ").append(String.join(", ", sjfStarved)).append("\n");
            sb.append("            These processes waited significantly longer than their burst time.\n");
        }
        List<String> prioStarved = new ArrayList<>();
        for (Process p : prioList) {
            if (p.wt > 3 * p.bt) prioStarved.add(p.id + " (WT=" + p.wt + ")");
        }
        if (prioStarved.isEmpty()) {
            sb.append("  Priority: No starvation detected in this workload.\n");
        } else {
            sb.append("  Priority: ⚠ Possible starvation — ").append(String.join(", ", prioStarved)).append("\n");
            sb.append("            Low-priority processes may wait indefinitely if high-priority\n");
            sb.append("            processes keep arriving (aging is not implemented here).\n");
        }
        sb.append("\n");

        
        sb.append("══════════════════════════════════════════════════════════════════════\n");
        sb.append("  2. METRICS CALCULATION RULES\n");
        sb.append("══════════════════════════════════════════════════════════════════════\n\n");
        sb.append("  CT  (Completion Time)  = The time at which the process finishes execution.\n");
        sb.append("  TAT (Turnaround Time)  = CT  - AT\n");
        sb.append("                         = Total time from arrival to completion.\n");
        sb.append("  WT  (Waiting Time)     = TAT - BT\n");
        sb.append("                         = Time spent waiting in the Ready Queue.\n");
        sb.append("  RT  (Response Time)    = Time process FIRST started running - AT\n");
        sb.append("                         = For non-preemptive: RT = WT (process runs once it starts).\n\n");
        sb.append("  Averages are computed over all n processes:\n");
        sb.append("    Avg WT  = Σ(WT)  / n\n");
        sb.append("    Avg TAT = Σ(TAT) / n\n");
        sb.append("    Avg RT  = Σ(RT)  / n\n\n");

        
        sb.append("══════════════════════════════════════════════════════════════════════\n");
        sb.append("  3. REQUIRED TEST SCENARIOS \n");
        sb.append("══════════════════════════════════════════════════════════════════════\n\n");
        sb.append("  Scenario A — Normal Case (all arrive at time 0, distinct BT & Pri):\n");
        sb.append("    P1: AT=0, BT=6, Pri=3 | P2: AT=0, BT=2, Pri=1 | P3: AT=0, BT=4, Pri=2\n");
        sb.append("    SJF order:      P2 → P3 → P1\n");
        sb.append("    Priority order: P2 → P3 → P1  (lower number = higher priority)\n\n");
        sb.append("  Scenario B — Behavior-Revealing (short BT vs high Priority conflict):\n");
        sb.append("    P1: AT=0, BT=10, Pri=1 | P2: AT=1, BT=1, Pri=3 | P3: AT=2, BT=2, Pri=2\n");
        sb.append("    SJF selects P2 first (shortest BT=1 when it arrives).\n");
        sb.append("    Priority selects P1 first (highest priority=1, already in queue).\n");
        sb.append("    → Demonstrates efficiency vs urgency trade-off.\n\n");
        sb.append("  Scenario C — Invalid Input Validation:\n");
        sb.append("    • Negative AT → Rejected: 'AT must be >= 0'\n");
        sb.append("    • BT = 0 or negative → Rejected: 'BT must be > 0'\n");
        sb.append("    • Non-numeric input → Rejected: 'AT, BT and Pri must be numeric'\n");
        sb.append("    • Duplicate ID → Rejected: 'Duplicate ID! Each process must have a unique ID'\n\n");

        
        sb.append("══════════════════════════════════════════════════════════════════════\n");
        sb.append("  4. REPORT & TECHNICAL EXPLANATION\n");
        sb.append("══════════════════════════════════════════════════════════════════════\n\n");

        sb.append("  Current Workload Results:\n");
        sb.append(String.format("    SJF      →  Avg WT: %.2f  |  Avg TAT: %.2f  |  Avg RT: %.2f%n",
                avgWT_SJF, avgTAT_SJF, avgRT_SJF));
        sb.append(String.format("    Priority →  Avg WT: %.2f  |  Avg TAT: %.2f  |  Avg RT: %.2f%n%n",
                avgWT_P, avgTAT_P, avgRT_P));

        sb.append("  Trade-off Analysis (Efficiency vs Urgency):\n");
        if (avgWT_SJF < avgWT_P) {
            sb.append("  • SJF achieves LOWER average waiting time (")
              .append(String.format("%.2f vs %.2f", avgWT_SJF, avgWT_P))
              .append(").\n");
            sb.append("    It is more EFFICIENT when all jobs are treated equally.\n");
        } else if (avgWT_P < avgWT_SJF) {
            sb.append("  • Priority achieves LOWER average waiting time (")
              .append(String.format("%.2f vs %.2f", avgWT_P, avgWT_SJF))
              .append(").\n");
            sb.append("    This happens when high-priority processes also have short burst times.\n");
        } else {
            sb.append("  • Both algorithms produce the SAME average waiting time for this workload.\n");
        }
        sb.append("\n");

        if (avgRT_SJF < avgRT_P) {
            sb.append("  • SJF has BETTER average response time (")
              .append(String.format("%.2f vs %.2f", avgRT_SJF, avgRT_P))
              .append(").\n");
        } else if (avgRT_P < avgRT_SJF) {
            sb.append("  • Priority has BETTER average response time (")
              .append(String.format("%.2f vs %.2f", avgRT_P, avgRT_SJF))
              .append(").\n");
            sb.append("    High-priority processes start quickly, giving better responsiveness\n");
            sb.append("    for critical tasks even if overall efficiency is lower.\n");
        } else {
            sb.append("  • Both algorithms have EQUAL average response time.\n");
        }
        sb.append("\n");

        sb.append("  Assumptions & Limitations:\n");
        sb.append("  • Both algorithms running process cannot be\n");
        sb.append("    interrupted mid-execution.\n");
        sb.append("  • SJF requires knowledge of burst times in advance (not practical in\n");
        sb.append("    real OSes without prediction). Priority scheduling is more practical\n");
        sb.append("    as priorities can be assigned by the OS or user.\n");
        sb.append("  • Neither algorithm implements AGING, so low-priority / long processes\n");
        sb.append("    may suffer starvation in workloads with continuous high-priority\n");
        sb.append("    or short arrivals.\n\n");

        sb.append("  Recommendation:\n");
        sb.append("  • Use SJF when all processes have equal importance and minimizing\n");
        sb.append("    average waiting time is the primary goal (batch systems).\n");
        sb.append("  • Use Priority Scheduling when processes have different urgency levels\n");
        sb.append("    (e.g., OS kernel tasks vs. user apps) and responsiveness for\n");
        sb.append("    critical processes matters more than overall efficiency.\n");

        return sb.toString();
    }

    private String getDefaultConclusionText() {
        return
            "══════════════════════════════════════════════════════════════════════\n" +
            "  CONCLUSION & ANALYSIS REPORT\n" +
            "══════════════════════════════════════════════════════════════════════\n\n" +
            "  Add processes and click   Compare Both   to generate the full\n" +
            "  analysis report including:\n\n" +
            "    1. Algorithm descriptions & selection basis (+ starvation check)\n" +
            "    2. Metrics calculation rules (CT, TAT, WT, RT formulas)\n" +
            "    3. Required test scenarios (normal, behavior-revealing, invalid input)\n" +
            "    4. Report & technical explanation with trade-off analysis\n\n" +
            "  Click   Run Single   after selecting SJF or Priority radio button\n" +
            "  to run a single algorithm and view its Gantt chart and results.\n";
    }
}
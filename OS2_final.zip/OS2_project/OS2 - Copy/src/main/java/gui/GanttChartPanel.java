package gui;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import model.GanttData;

public class GanttChartPanel extends JPanel {
    private List<GanttData> data;

    public void setData(List<GanttData> data) {
        this.data = data;
        this.revalidate();
        this.repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        if (data == null || data.isEmpty()) return;

        int padding = 40;
        int y = 40;
        int height = 50;
        
        
        int totalDuration = data.get(data.size() - 1).endTime;
        double availableWidth = getWidth() - (padding * 2);
        double scale = availableWidth / totalDuration;

        for (GanttData d : data) {
            int x = padding + (int) (d.startTime * scale);
            int width = (int) ((d.endTime - d.startTime) * scale);

            
            g2.setColor(new Color(220, 235, 250));
            g2.fillRect(x, y, width, height);
            
            
            g2.setColor(Color.BLACK);
            g2.setStroke(new BasicStroke(2));
            g2.drawRect(x, y, width, height);

            
            g2.setFont(new Font("Arial", Font.BOLD, 12));
            FontMetrics fm = g2.getFontMetrics();
            int textX = x + (width - fm.stringWidth(d.processId)) / 2;
            g2.drawString(d.processId, textX, y + 35);

            // كتابة أرقام الوقت بالأسفل
            g2.setFont(new Font("Arial", Font.PLAIN, 11));
            g2.drawString(String.valueOf(d.startTime), x, y + height + 20);
            
            // رسم الرقم الأخير في نهاية آخر عملية
            if (data.indexOf(d) == data.size() - 1) {
                g2.drawString(String.valueOf(d.endTime), x + width - 5, y + height + 20);
            }
        }
    }
}
package scheduler;

import model.Process;
import model.GanttData;
import java.util.*;

public class PriorityScheduler {
    public static List<GanttData> calculate(List<Process> processes) {
        List<GanttData> gantt = new ArrayList<>();

        // Copy data to avoid affecting the original list
        List<Process> pool = new ArrayList<>();
        for (Process p : processes) {
            pool.add(new Process(p.id, p.at, p.bt, p.pri));
        }

        int currentTime = 0;
        int completed = 0;
        int n = pool.size();
        List<Process> done = new ArrayList<>();

        while (completed < n) {
            // Collect all arrived processes in the Ready Queue
            List<Process> readyQueue = new ArrayList<>();
            for (Process p : pool) {
                if (p.at <= currentTime && !done.contains(p)) {
                    readyQueue.add(p);
                }
            }

            if (readyQueue.isEmpty()) {
                // If no arrived processes, increment time
                currentTime++;
                continue;
            }

            // Select process with highest priority (smallest number = highest priority)
            // When priority equal, select smallest AT then smallest BT
            readyQueue.sort(Comparator
                    .comparingInt((Process p) -> p.pri)
                    .thenComparingInt(p -> p.at)
                    .thenComparingInt(p -> p.bt));

            Process current = readyQueue.get(0);

            // RT = Start time - Arrival time
            current.rt = currentTime - current.at;

            // Add to Gantt Chart
            gantt.add(new GanttData(
                current.id.startsWith("P") ? current.id : "P" + current.id,
                currentTime,
                currentTime + current.bt
            ));

            // Update times
            currentTime += current.bt;
            current.ct  = currentTime;
            current.tat = current.ct - current.at;
            current.wt  = current.tat - current.bt;

            done.add(current);
            completed++;
        }

        // Copy results to original list
        for (int i = 0; i < n; i++) {
            Process orig = processes.get(i);
            for (Process p : pool) {
                if (p.id.equals(orig.id)) {
                    orig.ct  = p.ct;
                    orig.tat = p.tat;
                    orig.wt  = p.wt;
                    orig.rt  = p.rt;
                    break;
                }
            }
        }

        return gantt;
    }
}
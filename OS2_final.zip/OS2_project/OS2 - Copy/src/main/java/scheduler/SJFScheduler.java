package scheduler;
import model.Process;
import model.GanttData;
import java.util.*;

public class SJFScheduler {
    public static List<GanttData> calculate(List<Process> processes) {
        List<GanttData> gantt = new ArrayList<>();
        List<Process> readyQueue = new ArrayList<>();
        List<Process> pool = new ArrayList<>(processes);
        int currentTime = 0;
        int completed = 0;
        int n = processes.size();

        while (completed < n) {
            for (int i = 0; i < pool.size(); i++) {
                if (pool.get(i).at <= currentTime) {
                    readyQueue.add(pool.remove(i));
                    i--;
                }
            }

            if (readyQueue.isEmpty()) {
                currentTime++;
                continue;
            }

            readyQueue.sort(Comparator.comparingInt(p -> p.bt));
            Process p = readyQueue.remove(0);
            
            p.rt = currentTime - p.at;
            gantt.add(new GanttData(p.id, currentTime, currentTime + p.bt));
            currentTime += p.bt;
            p.ct = currentTime;
            p.tat = p.ct - p.at;
            p.wt = p.tat - p.bt;
            completed++;
        }
        return gantt;
    }
}
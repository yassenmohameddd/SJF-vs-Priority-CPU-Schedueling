package util;
import java.io.PrintWriter;

public class FileSaver {
    public static void saveToFile(String data) {
        try (PrintWriter out = new PrintWriter("log.txt")) {
            out.println(data);
        } catch (Exception e) { e.printStackTrace(); }
    }
}
package com.mycompany.os2;
import gui.MainGUI;
import javax.swing.SwingUtilities;

public class OS2 {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MainGUI().setVisible(true);
        });
    }
}